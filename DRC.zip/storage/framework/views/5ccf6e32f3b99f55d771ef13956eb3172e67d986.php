<!DOCTYPE html>
<html lang="en">
<head>
  <title>Profit Loss DRC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">          
  <table class="table">
    <thead>
      <tr>
        <th rows="2"></th>
        <th colspan="3">Buy</th>
        <th colspan="3">Sell</th>
        <th rowspa="2"></th>
        <th row="2"></th>        
      </tr>
      <tr>
        <th>Month-Year </th>
        <th>Qty</th>
        <th>Rate</th>
        <th>Total</th>
        <th>Qty</th>
        <th>Rate</th>
        <th>Total</th>
       <th>Remain stoke</th>
        <th>Profit/Loss</th> 
      </tr>
    </thead>
    <tbody>
      <?php foreach ($realdata as $key => $value) { ?>
        <tr>
        <td><?php echo e($key); ?></td>
        <?php if($value->buy): ?>        
        <?php $value1 = json_decode(json_encode($value->buy), true);  ?>
         <td><?php echo e($value1['qty']); ?></td>
         <td><?php echo e($value1['rate']); ?></td>
         <td><?php echo e($value1['total']); ?></td> 
         <?php else: ?>
         <td></td>
         <td></td>
         <td></td>     
        <?php endif; ?>
        <?php if($value->sell): ?>        
        <?php $value2 = json_decode(json_encode($value->sell), true);  ?>
         <td><?php echo e($value2['qty']); ?></td>
         <td><?php echo e($value2['rate']); ?></td>
         <td><?php echo e($value2['total']); ?></td>      
        <?php endif; ?>
        <td><?php echo e($value->remainStock); ?></td>
        <td><?php echo e($value->profitLoss); ?></td>
      </tr>
     <?php } ?>
      
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH D:\xammp\htdocs\DRC\resources\views/plview.blade.php ENDPATH**/ ?>