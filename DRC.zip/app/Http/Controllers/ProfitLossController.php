<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Excel;
use App\Imports\ProfitLoss;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Carbon\Carbon;
use DateTime;
use File;
use App\Models\CsvRead;
class ProfitLossController extends Controller
{

     public function index(){
     	$remainData = collect();
     	$remainStock = 0;
      	$csv_file_path = storage_path('app/unread/sample_data.csv');     
      	$put_path = storage_path('app/read/sample_data.csv');
  
   				$i = 0;
   		$result = (new ProfitLoss)->toCollection($csv_file_path)->first();
   		//dd($result);
   		$data = $result->sortBy(function($result,$key){
   		
   		    $last =	Carbon::createFromFormat('M-y',$result['monthyear'])->timestamp;
   		 
   				//return $last;
   				return [$last,$result['type']];
   		
   		})->groupBy('monthyear')->map(function($data,$index) use(&$remainData,&$remainStock,&$i){
   				$buyingdata = $data->where('type',1)->first();
   				$sellingdata = $data->where('type',2)->first();

   				$sellBooking = $buyBooking = 0;
   				$remainQyt = $buyingdata['qty'] - $sellingdata['qty']; 
		   		if($i != 0){
	   				$remainData->push([
   						'qyt' => $buyingdata['qty'],
	   					'rate' => $buyingdata['rate'],
	   				]);					
		   		}
   				if($remainData->isNotEmpty()){
					$remainBooking = getRemainBooking($remainData,$sellingdata['qty'],$index);					
   				}else{
					$remainBooking = ($sellingdata['qty'] ?? 0) * $buyingdata['rate'];
   				}
   				if($sellingdata){
   					$sellBooking = $sellingdata['qty'] * $sellingdata['rate'];
   				}
   				if($buyingdata){
   					$buyBooking = ($sellingdata['qty'] ?? 0) * $buyingdata['rate'];
   					if($i == 0){
						$remainData->push([
	   						'qyt' => abs($remainQyt),
		   					'rate' => $buyingdata['rate'],
		   				]);
			   		}
   				}		
   				$remainStock = $remainStock + ( $remainQyt );
   				$profitLoss = $sellBooking - $remainBooking;

   				// dump("profitLoss => .$profitLoss",$remainData);	
   				$i = $i + 1;
   				return [
   					'monthyear' => 	$index,
   					'buy' => $buyingdata,
   					'sell' => $sellingdata,
   					'profitLoss'=>$profitLoss,
   					'remainStock'=>$remainStock,
   				];
   		});
   		
        $data->all();
        $filename =  basename($csv_file_path);
        //copy file in read folder using file
        File::copy($csv_file_path,$put_path);
        // save enrty in database using model
        $CsvRead = new CsvRead;
        $CsvRead->file_name      = $filename;
        $CsvRead->read_date_time = Carbon::now()->format('Y-m-d H:i:s');
        $CsvRead->save();
        $realdata = json_decode(json_encode($data));
        return view('plview', compact('realdata')); 
 
     }
}
