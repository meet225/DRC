<?php

function getRemainBooking(&$remainData,$qyt,$index){
	$remainBooking = 0;
	$requiredQyt = 0;
	while ( $qyt > $requiredQyt) {
		$data = $remainData->filter()->values()->first();
		$dataQyt = $data['qyt'];
		$dataRate = $data['rate'];
		$qyts = abs($requiredQyt - $qyt);

		
		if($dataQyt >=  $qyts){
			$remainBooking = $remainBooking +  ($qyts * $dataRate);

			$requiredQyt = $requiredQyt + $qyts;
			$remainData = $remainData->replace([ 0 => ['qyt' => $data['qyt'] - $qyts ,'rate' => $data['rate']]])->where('qyt',"!=",0)->values();
		}else{
			$remainBooking = $remainBooking +  ($dataQyt * $dataRate);

			$requiredQyt = $requiredQyt + $dataQyt;
			$remainData = $remainData->replace([ 0 => []])->filter()->values();
		}
	}
	return $remainBooking;
}