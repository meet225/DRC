<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CsvRead extends Model
{
    use HasFactory;
    protected $table = 'csv_read_files';
}
